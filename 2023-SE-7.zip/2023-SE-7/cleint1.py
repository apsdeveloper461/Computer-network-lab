import socket

import threading
import os


def handle_repsonse_system(client_socket,command):  
        if command.startswith('/msg') :
            print(client_socket.recv(1024).decode())
        elif command.startswith('/file'):
            op=command.split(' ')[1];
            if op=='upload':
                try: # it handles exceptoion during file is read 
                    filename=command.split(' ')[2]
                    
                    file_size = os.path.getsize(filename)
                    client_socket.send(str(file_size).encode())
                    with open(filename, 'rb') as f:
                        print(f"Message : Starting to read the file : {filename}")
                        #sedn file size to server
                        send_bytes=f.read(1024);
                        while send_bytes:
                            client_socket.send(send_bytes)
                            print("hlo")
                            send_bytes=f.read(1024);
                        print("send succ")
                        res=client_socket.recv(1024).decode();
                        print(res);
                except FileNotFoundError:
                    print(f"Error: Filename is not exist,with error no : {FileNotFoundError.errno}");
        elif command.startswith('/group'):
            op=command.split(' ')[1];
            if op=='create':
                print("create group here")
            elif op=='join':
                print("join group here")
            elif op=='leave':
                print("leave group here")
        elif command == '/exit':
            exit();
        elif command == '/onlinelist' or command == '/allgroups' or command == '/joinedgroups':
           
            res=client_socket.recv(1024).decode();
            print(res);
        else:
            print("Invalid command. Please try again.")


def getINputFromUser():
    while True:
        print("\nAvailable Commands:")
        print("/msg : text\n/file upload filename\n/filelist\n/onlinelist\n/allgroups\n/joinedgroups")
        print("\n/group join groupname\n/group leave groupname\n/exit")

            # Input from the user
        command = input("Enter command: ")
        if command == '/exit' or command == '/onlinelist' or command == '/allgroups' or command == '/joinedgroups':
            return command;
        elif command.startswith('/msg') and len(command.split(':')) == 2:
            return command;
        elif command.startswith('/file upload') and len(command.split(' ')) == 3:
            if os.path.exists(command.split(' ')[2]):
                return command;
            else: 
                print("File not found. Please try again.");
        elif (command.startswith('/group create') or command.startswith('/group join') or command.startswith('/group leave')) and len(command.split(' '))==3:
            return command;
        else:
            print("Invalid command. Please try again.")
        continue;
 

def receivemessage(client_socket):
    while True:
        try:
            message = client_socket.recv(1024).decode()
            print("\n",message)
            break;
        except: 
            print("Connection to server lost.")
            client_socket.close();
            break
def client_messages_system(client_socket):
    threading.Thread(target=receivemessage,args=(client_socket,)).start(); 
    while True:
        try:
            message =getINputFromUser();
            client_socket.sendall(message.encode())
            handle_repsonse_system(client_socket,message);
        except: 
            print("Connection to server lost.")
            client_socket.close();
            break



def start_client():
    try:    
        client_socket = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
        client_socket.connect(('localhost', 1096))
        str=client_socket.recv(1024).decode()  
        res=input(str)
        client_socket.sendall(res.encode())
        response=client_socket.recv(1024).decode()
        if "Error" in response:
            print(response);
        else:
            print(response);
            client_messages_system(client_socket)

    except Exception as e:
        print(f"An error occurred: {e}")
    finally:    
        client_socket.close()


if __name__ == '__main__':
    start_client()