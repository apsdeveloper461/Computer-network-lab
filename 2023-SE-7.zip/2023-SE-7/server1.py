

import socket
import threading
import os


client_auth=[{'username': 'password','username1': 'password1', 'username2': 'password2'}]
clients=[]

groups = {'group1': ['username'], 'group2': ['username2']}   # Dictionary to manage groups and members

upload_dir = 'server_files'


    
def broadcast_msg(msg):
    for client in clients:
        client[1].sendall(msg.encode())


def remove_client(username):
    clients = [client for client in clients if client[0] != username];
    
    
def serverside_messages_system(client_socket, username,command):
       
        if command.startswith('/msg') :
            msg=username+" : "+command.split(':')[1]
            broadcast_msg(msg)
        elif command.startswith('/file'):
            op=command.split(' ')[1];
            if op=='upload':
                file_size=int(client_socket.recv(1024).decode())
                file_name=command.split(' ')[2];
                file_path = os.path.join(upload_dir, file_name);
                print(f"Receiving file name : {file_path}");
                received_data=b"";
                while len(received_data) < file_size:  
                    rec = client_socket.recv(1024)
                    print("Jlo")
                    received_data+=rec;
                with open(file_path, 'wb') as f:
                    print("start to write")
                    f.write(received_data) # Write the received data to the file
                    client_socket.sendall(b"File uploaded successfully to server.");
                    print(f"File {file_name} uploaded successfully to{upload_dir}.");
                
        elif command.startswith('/group'):
            op=command.split(' ')[1];
            if op=='create':
                print("create group here")
            elif op=='join':
                print("join group here")
            elif op=='leave':
                print("leave group here")
        elif command == '/exit':
            if username in clients:
                remove_client(username)
            print("Client disconnected");
            client_socket.close();
        elif command == '/onlinelist':
            online_users = [client[0] for client in clients]
            client_socket.send(f"Online Users: {', '.join(online_users)}".encode())
        elif command == '/allgroups':
            all_groups = ', '.join(groups.keys())
            client_socket.send(f"Available Groups: {all_groups}".encode());
        elif command == '/joinedgroups':
            user_groups = [group for group, members in groups.items() if username in members]
            client_socket.send(f"Your Groups: {', '.join(user_groups)}".encode())

        else:
            print("Invalid command. Please try again.")
            
            
def handle_client(client_socket,username):  
    print(f"Client {username} connected with autherized credentials")   
    while True:
        try:
            data = client_socket.recv(1024).decode()
            serverside_messages_system(client_socket, username, data);
        except Exception as e:  
            print(f"An error occurred: {e}")
            break


    


def start_server():
    server_socket = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
    server_socket.bind(('127.0.0.1', 1096))
    server_socket.listen(10)
    print('Server started on localhost:1096')

    try:
        while True:
            client_socket, client_address = server_socket.accept()
            print(f'Client connected from {client_address}')
            client_socket.sendall("Enter username and password in format username:password(without spaces and quote marks) :".encode())
            res=client_socket.recv(1024).decode();
            print("Len",len(res.split(':')))
            if len(res.split(':'))==2:
                username, password = res.split(':')
                for user in client_auth:
                    if username in user:
                        if user[username]==password:
                            client_socket.sendall('Success: Authenticated'.encode())
                            clients.append([username,client_socket,True])
                            threading.Thread(target=handle_client,args=(client_socket, username,)).start();
                            break;
                    else:
                        client_socket.sendall("Error: Unauthenticated".encode())     
                        print("Error: Unauthenticated") 
            else:
                client_socket.sendall("Error: Unauthenticated".encode())   
                print("Error: Unauthenticated") 
    except Exception as e:
        print(f"Server error: {e}")
    finally:
        server_socket.close()




if __name__=='__main__':
    start_server();