import socket
import threading

# List to store connected clients
clients = []

def handle_client(client_socket):
    while True:
        try:
            # Receive message from client
            message = client_socket.recv(1024).decode('utf-8')
            if not message:
                break
            print(f"Received: {message}")

            # Broadcast the message to all clients except the sender
            broadcast(message, client_socket)
        except:
            # Remove client if there is an error
            clients.remove(client_socket)
            client_socket.close()
            break

# Function to broadcast the message
def broadcast(message, sender_socket):
    for client in clients:
        if client != sender_socket:
            try:
                client.send(message.encode('utf-8'))
            except:
                # Handle broken connection
                clients.remove(client)
                client.close()

# Server setup
def server_program():
    server_socket = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
    server_socket.bind(('127.0.0.1', 12345))
    server_socket.listen()

    print("Server is listening...")

    while True:
        # Accept new connection
        client_socket, address = server_socket.accept()
        print(f"Connection from {address}")

        # Add new client to the list
        clients.append(client_socket)

        # Create a new thread for each client
        thread = threading.Thread(target=handle_client, args=(client_socket,))
        thread.start()

if __name__ == "__main__":
    server_program()
