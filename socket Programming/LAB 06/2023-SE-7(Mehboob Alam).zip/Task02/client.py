import socket
import threading

# Function to receive messages from  server
def receive_messages(client_socket):
    while True:
        try:
            message = client_socket.recv(1024).decode()
            if message:
                print(message)
        except:
            print("An error occurred.")
            client_socket.close()
            break


def client_program():
    client_socket = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
    client_socket.connect(('127.0.0.1', 23456))

    username = input("Enter your username: ")
    client_socket.send(username.encode())

    # Start a thread to receive messages
    receive_thread = threading.Thread(target=receive_messages, args=(client_socket,))
    receive_thread.start()

    while True:
        message = input(f"{username}: ")
        client_socket.send(message.encode())

if __name__ == "__main__":
    client_program()
