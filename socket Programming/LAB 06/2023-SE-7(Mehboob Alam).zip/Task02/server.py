import socket
import threading

# List to store clients and their usernames
clients = []

# Function to handle client connection
def handle_client(client_socket):
    # Receive the username 
    username = client_socket.recv(1024).decode()
    welcome_message = f"{username} has joined the chat!"
    print(welcome_message)

    # Broadcast 
    broadcast(welcome_message, client_socket)

    while True:
        try:
            # e message from client
            message = client_socket.recv(1024).decode()
            if not message:
                break
            formatted_message = f"{username}: {message}"
            print(formatted_message)

            # Broadcast  message to all clients except the sender
            broadcast(formatted_message, client_socket)
        except:
            #  client disconnect
            print(f"{username} has left the chat.")
            clients.remove(client_socket)
            client_socket.close()
            broadcast(f"{username} has left the chat.", client_socket)
            break

#  broadcast messages to clients except the sender
def broadcast(message, sender_socket):
    for client in clients:
        if client != sender_socket:
            try:
                client.send(message.encode())
            except:
                clients.remove(client)
                client.close()


def server_program():
    server_socket = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
    server_socket.bind(('127.0.0.1', 23456))
    server_socket.listen(5)

    print(f"Server is listening on  ' port No : 23456' ...")

    while True:
        # Accept new connection
        client_socket, address = server_socket.accept()
        print(f"Connection with ::  {address}")

        # Add new client to the list
        clients.append(client_socket)

        # Start a new thread client
        thread = threading.Thread(target=handle_client, args=(client_socket,))
        thread.start()

if __name__ == "__main__":
    server_program()
