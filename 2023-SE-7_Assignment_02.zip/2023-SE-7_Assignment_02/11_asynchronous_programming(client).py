import asyncio

async def create_client_socket():
    reader, writer = await asyncio.open_connection('localhost', 1096)

    try:
        while True:
            command = input("Enter command (LIST to show files, 'DOWNLOAD filename' to download file, 'DELETE filename' to delete file, 'RENAME oldname newname' to rename a file): ")
            writer.write(command.encode())
            await writer.drain()

            if command == 'LIST':
                data = await reader.read(1024)
                print("Available files on server:\n" + data.decode())
            elif command.startswith('DOWNLOAD'):
                res = await reader.read(1024)
                if res.startswith(b"Error"):
                    print(res.decode())
                    break
                file_size = int(res.decode())
                print(f"File size: {file_size} bytes")
                if file_size == 0:
                    print("Error: File not found on server.")
                    continue
                file_name = command.split(' ')[1]
                with open(f"downloaded_from_server_{file_name}", 'wb') as file:
                    received_data = b""
                    while len(received_data) < file_size:
                        chunk = await reader.read(1024)
                        if not chunk:
                            break
                        received_data += chunk
                    file.write(received_data)
                    print(f"File '{file_name}' downloaded successfully.")
            elif command.startswith('DELETE'):
                res = await reader.read(1024)
                print(res.decode())
            elif command.startswith('RENAME'):
                res = await reader.read(1024)
                print(res.decode())
            else:
                print("Invalid command.")
    except Exception as e:
        print(f"Error: {e}")
    finally:
        writer.close()
        await writer.wait_closed()

# Main entry point for the client
if __name__ == "__main__":
    asyncio.run(create_client_socket())
