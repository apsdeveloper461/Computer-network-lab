import socket
import os
MAX_FILE_SIZE=1*1024    #10kb


def start_ftp_server(upload_dir):
    if not os.path.exists(upload_dir):
        os.makedirs(upload_dir);
    server_socket=socket.socket(socket.AF_INET,socket.SOCK_STREAM);
    server_address=('localhost',1096);
    server_socket.bind(server_address);

    # listen for incoming connection 
    server_socket.listen(1);
    print("FTP server is listening on port 1096...");

    while True:
        connection,client_address=server_socket.accept();
        try:
            print(f"Client Connect with Ip address : {client_address}");
            #get file size
            file_size=int(connection.recv(1024).decode())
            print(f"Size of file is {file_size}bytes")
                #check fiel size herre
            if file_size>MAX_FILE_SIZE:
                connection.send(b"Error: File size exceeds maximum limit of file")
                print("file is exceds the max file size")
            else:
                filename=connection.recv(1024).decode();
                # Create the full path to save the uploaded file
                file_path = os.path.join(upload_dir, filename);
                count = 1
                while os.path.exists(file_path):
                    file_name = f"{os.path.splitext(filename)[0]}_{count}{os.path.splitext(filename)[1]}"
                    file_path = os.path.join(upload_dir, file_name)
                    count += 1
                print(f"Receiving file name : {file_path}");
                received_data=b"";
                while len(received_data) < file_size:  
                    rec = connection.recv(1024)
                    if not rec:
                        break
                    received_data+=rec;
                with open(file_path, 'wb') as f:
                    f.write(received_data) # Write the received data to the file
                    connection.send(b"File uploaded successfully to server.");
                    print(f"File {filename} uploaded successfully to{upload_dir}.");
        except Exception as e:  
            print(e);
            break;
            
        finally:
            connection.close();
            print(f"Connection closed with {client_address}")          






if __name__ == '__main__':
    upload_dir='upload_files_to_server';

    start_ftp_server(upload_dir);



