



import socket
import os



def start_ftp_client():
    cleint_socket=socket.socket(socket.AF_INET,socket.SOCK_STREAM);
    server_address=('localhost',1096);
    try:  # this is handle error if server not coonect or any error in connection
        cleint_socket.connect(server_address);
    except ConnectionRefusedError:
        print(f"Error : server not started/Connection refused error from server address: {server_address}\n");
        exit();
    try:   # it handle error during conservation with server  after connecting server
        while True:
            filename = input("Enter the name of the file to upload (or 'exit' to quit): ")
            if filename.lower() == 'exit':
                print(f"Exit : Going to exit the program")
                break;
            try: # it handles exceptoion during file is read 
                with open(filename, 'rb') as f:
                    print(f"Message : Starting to read the file : {filename}")
                    #sedn file size to server
                    file_size = os.path.getsize(filename)
                    cleint_socket.send(str(file_size).encode())
                    cleint_socket.send(filename.encode())
                    send_bytes=f.read(1024);
                    while send_bytes:
                        cleint_socket.send(send_bytes)
                        send_bytes=f.read(1024);
                    res=cleint_socket.recv(1024).decode();
                    print(res);
            except FileNotFoundError:
                print(f"Error: Filename is not exist,with error no : {FileNotFoundError.errno}");
    except ConnectionResetError:  # ifserver is shutdown during connection it handle this error
        print(f"Error : Connection is reset, with errror no : {ConnectionResetError.errno} ")
    except ConnectionError:
        print(f"Error : connection error, with error no : {ConnectionError.errno} ")
    finally:
        cleint_socket.close();
        print(f"Connection closed with {server_address}")          







if __name__ == '__main__':  
    start_ftp_client();



