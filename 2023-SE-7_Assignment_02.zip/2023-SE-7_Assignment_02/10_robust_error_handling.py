import socket
import os
import threading
import logging
from tqdm import tqdm

SHARED_PASSWORD = "mehboob_alam"  

file_size = 100 * 1024  # 100kb file size

log_file = "log.txt"  

logging.basicConfig(
    level=logging.INFO, 
    format='%(asctime)s - %(levelname)s - %(message)s',  # Log format
    handlers=[
        logging.FileHandler(log_file),  # Log to a file
        logging.StreamHandler()  # Log to console
    ]
)

logger = logging.getLogger()

# For getting list of files in the directory
def list_files(client_socket):
    try:
        files = os.listdir(upload_dir)
        file_list = "\n".join(files)
        client_socket.sendall(file_list.encode())
        logger.info("Sent file list to client.")
    except Exception as e:
        logger.error(f"Error while listing files: {e}")
        client_socket.sendall(b"Error: Unable to list files.")

def send_data_to_client(client_socket, filepath):
    try:
        file_size = os.path.getsize(filepath)
        client_socket.sendall(str(file_size).encode()) 

        with open(filepath, 'rb') as f:
            chunk = f.read(1024)
            pbar = tqdm(total=file_size, unit='B', unit_scale=True, desc=filepath)  # Progress bar setup
            while chunk:
                client_socket.sendall(chunk)
                pbar.update(len(chunk))  # Update the progress bar
                chunk = f.read(1024)
            pbar.close()
        logger.info(f"File '{filepath}' sent to client.")
    except FileNotFoundError:
        logger.error(f"File '{filepath}' not found.")
        client_socket.sendall(b"Error: File not found.")
    except IOError as e:
        logger.error(f"IO error occurred while sending file: {e}")
        client_socket.sendall(b"Error: IO error occurred while sending the file.")
    except Exception as e:
        logger.error(f"Unexpected error while sending file '{filepath}': {e}")
        client_socket.sendall(b"Error: Unexpected error occurred during file transfer.")

# Handle client connection
def handle_client_connection(client_socket):
    try:
        # Ask for password authentication
        client_socket.sendall(b"Please enter the password to continue: ")
        password = client_socket.recv(1024).decode().strip()

        if password != SHARED_PASSWORD:
            logger.warning("Failed authentication attempt.")
            client_socket.sendall(b"Error: Incorrect password. Connection closed.")
            client_socket.close()
            return

        client_socket.sendall(b"Password accepted. You can now use the server.")

        while True:
            command = client_socket.recv(1024).decode().strip()
            logger.info(f"Received command: {command}")
            if command == 'LIST':
                list_files(client_socket)
            elif command.startswith('DOWNLOAD'):
                if command == "DOWNLOAD":
                    client_socket.sendall(b"Error: File not specified.")
                    break
                file_name = command.split(' ')[1]
                file_path = os.path.join('upload_files_to_server', file_name)
                if os.path.exists(file_path):
                    send_data_to_client(client_socket, file_path)
                else:
                    client_socket.sendall(b"Error: File not found.")
            else:
                client_socket.sendall(b"Error: Invalid command")
    except socket.error as e:
        logger.error(f"Socket error occurred: {e}")
        client_socket.sendall(b"Error: Socket communication error.")
    except Exception as e:
        logger.error(f"Unexpected error occurred while handling client: {e}")
        client_socket.sendall(b"Error: Unexpected error occurred.")
    finally:
        client_socket.close()

# Start server
def start_server():
    server_socket = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
    try:
        server_socket.bind(('localhost', 1096))
        server_socket.listen(5)
        logger.info("Server listening on port 1096...")
    except socket.error as e:
        logger.critical(f"Server failed to start: {e}")
        return

    while True:
        try:
            client_socket, addr = server_socket.accept()
            logger.info(f"Connection with client address: {addr}")
            threading.Thread(target=handle_client_connection, args=(client_socket,)).start()
        except Exception as e:
            logger.error(f"Error while accepting client connection: {e}")

# Create connection client with server
def create_client_socket():
    client_socket = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
    try:
        client_socket.connect(('localhost', 1096))
        logger.info("Connected to the server.")
    except socket.error as e:
        logger.error(f"Failed to connect to the server: {e}")
        return

    try:
        # Send the password for authentication
        res=client_socket.recv(1024).decode();
        password = input(res)
        client_socket.sendall(password.encode())

        # Receive server's response regarding authentication
        auth_response = client_socket.recv(1024).decode()
        if "Error" in auth_response:
            logger.error(auth_response)  # If authentication failed
            print(auth_response)
            return

        print(auth_response)  # If authentication is successful

        while True:
            command = input("Enter command (LIST to display all, 'DOWNLOAD filename' for downloading file): ")
            client_socket.sendall(command.encode())
            if command == 'LIST':
                file_list = client_socket.recv(1024).decode()
                print("Available files on server:\n" + file_list)
            elif command.startswith('DOWNLOAD'):
                res = client_socket.recv(1024).decode()
                if res.startswith('Error'):
                    logger.error(f"Error from server: {res}")
                    print(res)
                    break
                file_size = int(res)
                print("File size:", file_size)
                if file_size == 0:
                    logger.warning("Error: File not found on server.")
                    print("Error: File not found on server.")
                    continue
                file_name = command.split(' ')[1]
                
                # Set up the progress bar for downloading
                with open(f"downloaded_from_server_{file_name}", 'wb') as file:
                    received_data = b""
                    pbar = tqdm(total=file_size, unit='B', unit_scale=True, desc=file_name)  
                    while len(received_data) < file_size:
                        chunk = client_socket.recv(1024)
                        if not chunk:
                            break
                        received_data += chunk
                        pbar.update(len(chunk))
                    file.write(received_data)
                    pbar.close()
                    logger.info(f"File '{file_name}' downloaded successfully.")
                    print(f"File '{file_name}' downloaded successfully.")
            else:
                logger.warning("Invalid command entered by the user.")
                print("Invalid command.")

    except socket.error as e:
        logger.error(f"Socket error occurred: {e}")
    except Exception as e:
        logger.error(f"Unexpected error occurred in client: {e}")
    finally:
        client_socket.close()

if __name__ == "__main__":
    upload_dir = 'upload_files_to_server'
    if not os.path.exists(upload_dir):
        os.makedirs(upload_dir)

    while True:
        choice = input("Enter 'server' to run the server, 'client' to run the client, or 'exit' to exit the program: ").strip().lower()
        if choice == 'server':
            start_server()
        elif choice == 'client':
            create_client_socket()
        elif choice == 'exit':
            break
        else:
            logger.warning("Invalid input.")
            print("Invalid input.")
