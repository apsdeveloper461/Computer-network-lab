import socket
import os
import threading
from tqdm import tqdm

SHARED_PASSWORD = "mehboob_alam"  # secure password for encryption

file_size = 100 * 1024  # 100kb file size

# For getting list of files in the directory
def list_files(client_socket):
    files = os.listdir(upload_dir)
    file_list = "\n".join(files)
    client_socket.sendall(file_list.encode())

def send_data_to_client(client_socket, filepath):
    file_size = os.path.getsize(filepath)
    client_socket.sendall(str(file_size).encode())  # Send file size first
    
    # Initialize the progress bar using tqdm
    with open(filepath, 'rb') as f:
        chunk = f.read(1024)
        pbar = tqdm(total=file_size, unit='B', unit_scale=True, desc=filepath)  # Progress bar setup
        while chunk:
            client_socket.sendall(chunk)
            pbar.update(len(chunk))  # Update the progress bar
            chunk = f.read(1024)
        pbar.close()
        print(f"File '{filepath}' sent to client.")

# Handle client connection
def handle_client_connection(client_socket):
    try:
        # Ask for password authentication
        client_socket.sendall(b"Please enter the password to continue: ")
        password = client_socket.recv(1024).decode().strip()

        if password != SHARED_PASSWORD:
            client_socket.sendall(b"Error: Incorrect password. Connection closed.")
            print("Failed authentication attempt.")
            client_socket.close()
            return

        client_socket.sendall(b"Password accepted. You can now use the server.")

        while True:
            command = client_socket.recv(1024).decode().strip()
            print(command, command.startswith("DOWNLOAD"))
            if command == 'LIST':
                list_files(client_socket)
            elif command.startswith('DOWNLOAD'):
                if command == "DOWNLOAD":
                    client_socket.sendall(b"Error: File not specified.")
                    break
                file_name = command.split(' ')[1]
                file_path = os.path.join('upload_files_to_server', file_name)
                if os.path.exists(file_path):
                    print("File exists")
                    send_data_to_client(client_socket, file_path)
                else:
                    client_socket.sendall(b"Error: File not found.")
            else:
                client_socket.sendall(b"Error: Invalid command")
    except Exception as e:
        print(f"Error occurred: {e}")
    finally:
        client_socket.close()

# Start server
def start_server():
    server_socket = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
    server_socket.bind(('localhost', 1096))
    server_socket.listen(5)
    print("Server listening on port 1096...")

    while True:
        client_socket, addr = server_socket.accept()
        print(f"Connection with client address: {addr}")
        threading.Thread(target=handle_client_connection, args=(client_socket,)).start()

def create_client_socket():
    try:
        client_socket = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
        client_socket.connect(('localhost', 1096))

        # Send the password for authentication
        res=client_socket.recv(1024).decode();
        password = input(res)
        client_socket.sendall(password.encode())

        # Receive server's response regarding authentication
        auth_response = client_socket.recv(1024).decode()
        if "Error" in auth_response:
            print(auth_response)  # If authentication failed
            return

        print(auth_response)  # If authentication is successful

        while True:
            command = input("Enter command (LIST to display all, 'DOWNLOAD filename' for downloading file): ")
            client_socket.sendall(command.encode())
            if command == 'LIST':
                file_list = client_socket.recv(1024).decode()
                print("Available files on server:\n" + file_list)
            elif command.startswith('DOWNLOAD'):
                res = client_socket.recv(1024).decode()
                if res.startswith('Error'):
                    print(res)
                    break
                file_size = int(res)
                print("File size:", file_size)
                if file_size == 0:
                    print("Error: File not found on server.")
                    continue
                file_name = command.split(' ')[1]
                with open(f"downloaded_from_server_{file_name}", 'wb') as file:
                    received_data = b""
                    pbar = tqdm(total=file_size, unit='B', unit_scale=True, desc=file_name)  # Progress bar 
                    while len(received_data) < file_size:
                        chunk = client_socket.recv(1024)
                        if not chunk:
                            break
                        received_data += chunk
                        pbar.update(len(chunk))  # Update progress bar 
                    file.write(received_data)
                    pbar.close()
                    print(f"File '{file_name}' downloaded successfully.")
            else:
                print("Invalid command.")

    except Exception as e:
        print(f"Error: {e}")
    finally:
        client_socket.close()

if __name__ == "__main__":
    upload_dir = 'upload_files_to_server'
    if not os.path.exists(upload_dir):
        os.makedirs(upload_dir)
    while True:
        choice = input("Enter 'server' to run the server, 'client' to run the client, or 'exit' to exit the program: ").strip().lower()
        if choice == 'server':
            start_server()
        elif choice == 'client':
            create_client_socket()
        elif choice == 'exit':
            break
        else:
            print("Invalid input.")
