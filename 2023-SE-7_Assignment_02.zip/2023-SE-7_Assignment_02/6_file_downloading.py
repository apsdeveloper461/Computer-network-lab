import socket
import os
import threading

file_size=100*1024 #100kb file size


# for gettiing list of filees oin directive 
def list_files(client_socket):
    files = os.listdir(upload_dir)
    file_list = "\n".join(files)
    client_socket.sendall(file_list.encode())

def send_data_to_clinet(client_socket,filepath):
    file_size = os.path.getsize(filepath)
    client_socket.sendall(str(file_size).encode())  # Send file size first
    with open(filepath,'rb') as f:
        chunk=f.read(1024)
        while chunk:
            client_socket.sendall(chunk)
            chunk=f.read(1024)
        print(f"File '{filepath}' sent to client.")

# handle client connection 
def handle_client_connection(client_socket):
    try:
        while True:
            command = client_socket.recv(1024).decode().strip()
            print(command,command.startswith("DOWNLOAD"))
            if command == 'LIST':
                list_files(client_socket)
            elif command.startswith('DOWNLOAD'):
                if command=="DOWNLOAD":
                   client_socket.sendall(b"Error : File not speacify.")
                   break;
                file_name = command.split(' ')[1]
                file_path = os.path.join('upload_files_to_server', file_name)
                if os.path.exists(file_path):
                   print("File is exist")
                   send_data_to_clinet(client_socket,file_path);
                else:
                  client_socket.sendall(b"Error : File not found.")
            else:
                client_socket.sendall(b"Error : Invalid commad")
    except Exception as e:
        print(f"Error occurred: {e}")
    finally:
        client_socket.close()

# here start server with creating a socket 
def start_server():
    server_socket = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
    server_socket.bind(('localhost', 1096))
    server_socket.listen(5)
    print("Server listening on port 1096...")

    while True:
        client_socket, addr = server_socket.accept()
        print(f"Connection  with cleint address :  {addr}")
        threading.Thread(target=handle_client_connection, args=(client_socket,)).start()

# create connection cleint with server 
def create_client_socket():
    try:
        client_socket = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
        client_socket.connect(('localhost', 1096))

        while True:
            comnd = input("Enter command (LIST) for displaying all list 'DOWNLOAD filename' fro downaloading file from server  : ")
            client_socket.sendall(comnd.encode())
            if comnd == 'LIST':
                file_list = client_socket.recv(1024).decode()
                print("Available files on server :\n" + file_list)
            elif comnd.startswith('DOWNLOAD'):
                res = (client_socket.recv(1024).decode())
                # print(type(res),type(int(res)))
                if(res.startswith('Error')):
                    print(res);
                    break;
                file_size=(res);
                print("File size"+file_size)
                if int(file_size) == 0:
                    print("Error: File not found on server.")
                    continue
                file_name = comnd.split(' ')[1]
                with open(f"downloaded_from_server_{file_name}", 'wb') as file:
                    received_data = b""
                    while len(received_data) < int(file_size):
                        chunk = client_socket.recv(1024)
                        if not chunk:
                            break
                        received_data += chunk
                    file.write(received_data)
                    print(f"File '{file_name}' downloaded successfully.")

            else:
                print("Invalid command.")

    except Exception as e:
        print(f"Error : {e}")
    finally:
        client_socket.close()

if __name__ == "__main__":
    
    upload_dir='upload_files_to_server';
    if not os.path.exists(upload_dir):
        os.makedirs(upload_dir)
    while True:
        choice = input("Enter 'server' to run the server or 'client' to run the client or 'exit' for Exit Program : ").strip().lower()
        if choice == 'server':
            start_server()
        elif choice == 'client':
            create_client_socket()
        elif choice == 'exit':
            break;
        else:
         print("Invalid input.")
