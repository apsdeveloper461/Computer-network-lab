import socket
import os
import threading




# for gettiing list of filees oin directive 
def list_files(client_socket):
    files = os.listdir(upload_dir)
    file_list = "\n".join(files)
    client_socket.sendall(file_list.encode())

# handle client connection 
def handle_client_connection(client_socket):
    try:
        while True:
            command = client_socket.recv(1024).decode().strip()
            if command == 'LIST':
                list_files(client_socket)
            else:
                client_socket.sendall(b"Invalid command.")
    except Exception as e:
        print(f"Error occurred: {e}")
    finally:
        client_socket.close()

# here start server with creating a socket 
def start_server():
    server_socket = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
    server_socket.bind(('localhost', 1096))
    server_socket.listen(5)
    print("Server listening on port 1096...")

    while True:
        client_socket, addr = server_socket.accept()
        print(f"Connection  with cleint address :  {addr}")
        threading.Thread(target=handle_client_connection, args=(client_socket,)).start()

# create connection cleint with server 
def create_client_socket():
    try:
        client_socket = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
        client_socket.connect(('localhost', 1096))

        while True:
            comnd = input("Enter command (LIST) for displaying all directive of server available files : ")
            client_socket.sendall(comnd.encode())
            print(type(comnd),comnd=='LIST',comnd=="LIST")
            if comnd == 'LIST':
                file_list = client_socket.recv(1024).decode()
                print("Available files on server :\n" + file_list)
            else:
                print("Invalid command.")

    except Exception as e:
        print(f"Error : {e}")
    finally:
        client_socket.close()

if __name__ == "__main__":
    
    upload_dir='upload_files_to_server';
    if not os.path.exists(upload_dir):
        os.makedirs(upload_dir)
    while True:
        choice = input("Enter 'server' to run the server or 'client' to run the client or 'exit' for Exit Program : ").strip().lower()
        if choice == 'server':
            start_server()
        elif choice == 'client':
            create_client_socket()
        elif choice == 'exit':
            break;
        else:
         print("Invalid input.")
